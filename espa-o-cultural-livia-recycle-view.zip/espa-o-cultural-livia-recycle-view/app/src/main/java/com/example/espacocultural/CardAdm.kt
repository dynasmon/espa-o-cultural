package com.example.espacocultural

data class CardObra(
    val imageResId: Int,
    val title: String,
    val subtitle: String
)