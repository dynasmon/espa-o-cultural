package com.example.espacocultural

data class CardVisitante(
    val imageResId: Int,
    val titulo: String,
    val subtitulo: String
)
